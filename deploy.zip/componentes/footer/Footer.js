export default function Footer() {
  return (
    <footer>
      <p>footer</p>
    </footer>
  );
}
