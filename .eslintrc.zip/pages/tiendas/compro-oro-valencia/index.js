import React from "react";
import Contenedor from "../../../componentes/contenedor/Contenedor";

export default function Valencia() {
  return <Contenedor>Valencia</Contenedor>;
}
