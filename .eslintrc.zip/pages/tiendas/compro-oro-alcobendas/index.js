import React from "react";
import Contenedor from "../../../componentes/contenedor/Contenedor";

export default function Alcobendas() {
  return <Contenedor>Alcobendas</Contenedor>;
}
