exports.id = 997;
exports.ids = [997];
exports.modules = {

/***/ 5356:
/***/ ((module) => {

// Exports
module.exports = {
	"mas_precios_oro": "boton_mas_precios_oro__msBwf",
	"calculadora_oro": "boton_calculadora_oro__lLbwQ",
	"info_oro": "boton_info_oro__MbbF2"
};


/***/ }),

/***/ 4689:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor": "contenedor_contenedor__XIUjN"
};


/***/ }),

/***/ 9104:
/***/ ((module) => {

// Exports
module.exports = {
	"ejemplo_new": "empenoEjemplo_ejemplo_new__gwqJO",
	"boton_llamar_empenos": "empenoEjemplo_boton_llamar_empenos__LQV3C"
};


/***/ }),

/***/ 9792:
/***/ ((module) => {

// Exports
module.exports = {
	"bloqueTitulo": "empenoInfo_bloqueTitulo__3KWaE",
	"empeno_der": "empenoInfo_empeno_der__mdxUy",
	"caracteristica_empeno": "empenoInfo_caracteristica_empeno__YPtoP",
	"porcentaje": "empenoInfo_porcentaje__jTFNV",
	"texto": "empenoInfo_texto__i7KYD",
	"info_empenos": "empenoInfo_info_empenos__E4UeW",
	"boton_llamar_empenos": "empenoInfo_boton_llamar_empenos__b1NEi"
};


/***/ }),

/***/ 1146:
/***/ ((module) => {

// Exports
module.exports = {
	"empenos": "empenos_empenos___ly9I",
	"contenedor_empenos": "empenos_contenedor_empenos__AYZZS",
	"boton_llamar_empenos": "empenos_boton_llamar_empenos__3xQ2E",
	"contenedor_img_empenos": "empenos_contenedor_img_empenos__6mIoz",
	"contenedor_botones": "empenos_contenedor_botones___DoAb",
	"contenedor_modal": "empenos_contenedor_modal__sp4Vq"
};


/***/ }),

/***/ 4802:
/***/ ((module) => {

// Exports
module.exports = {
	"cabecera_titulo": "info_tiendas_cabecera_titulo__eqNaL",
	"cabecera_estrellas": "info_tiendas_cabecera_estrellas__ioG2E",
	"contenedor_cabecera_tienda": "info_tiendas_contenedor_cabecera_tienda__IimZW",
	"contenedor_izq": "info_tiendas_contenedor_izq__MpDsq",
	"numero_reviews": "info_tiendas_numero_reviews__cwgdr",
	"boton_review": "info_tiendas_boton_review__F1ErW",
	"direccion": "info_tiendas_direccion__lQMOd",
	"provincia": "info_tiendas_provincia__bpyRD",
	"telefono_tienda": "info_tiendas_telefono_tienda__ge_M5",
	"contenedor_botones_tienda": "info_tiendas_contenedor_botones_tienda__nIq8o",
	"bloque_der": "info_tiendas_bloque_der__ZboAy",
	"horario_tienda": "info_tiendas_horario_tienda__d7hAf",
	"lista_horario": "info_tiendas_lista_horario__b2b__",
	"whatsapp_tienda": "info_tiendas_whatsapp_tienda__ZVHky",
	"llamar": "info_tiendas_llamar__GxnN9",
	"mapa_tienda": "info_tiendas_mapa_tienda__q8lpE",
	"img_stars": "info_tiendas_img_stars__w6Q_3",
	"imgValoracion": "info_tiendas_imgValoracion__V7qUM",
	"logo_google": "info_tiendas_logo_google__Q36zR"
};


/***/ }),

/***/ 7718:
/***/ ((module) => {

// Exports
module.exports = {
	"invertir": "invertir_invertir__NqBof",
	"contenedor_tabla": "invertir_contenedor_tabla__gihNx",
	"titulo": "invertir_titulo__Jl_yg",
	"precio": "invertir_precio__GuGTU",
	"tooltip": "invertir_tooltip__N8zrO",
	"tooltiptext": "invertir_tooltiptext__dHUDP"
};


/***/ }),

/***/ 1199:
/***/ ((module) => {

// Exports
module.exports = {
	"mapa_tienda_popup": "mapa_tienda_mapa_tienda_popup___OnO_"
};


/***/ }),

/***/ 3673:
/***/ ((module) => {

// Exports
module.exports = {
	"ventana_modal": "modal_ventana_modal__ZfhDY",
	"boton_cerrar": "modal_boton_cerrar__UB8t5",
	"is_open": "modal_is_open__sX_xr"
};


/***/ }),

/***/ 4565:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_precio_divisa": "precio_divisa_contenedor_precio_divisa__w1cuz",
	"bloque_divisa": "precio_divisa_bloque_divisa__0lkXZ",
	"contenedor_botones_divisas": "precio_divisa_contenedor_botones_divisas__Xvykc",
	"divisa_activa": "precio_divisa_divisa_activa__AK4Wu",
	"vender_divisa": "precio_divisa_vender_divisa__89OLp",
	"comprar_divisa": "precio_divisa_comprar_divisa__OtNFt",
	"precio_divisas": "precio_divisa_precio_divisas__rQYcD",
	"contenedor_der_divisa": "precio_divisa_contenedor_der_divisa__JU5vA",
	"contenedor_izq_divisa": "precio_divisa_contenedor_izq_divisa__UYvaL",
	"precio_divisas_dolar": "precio_divisa_precio_divisas_dolar__kLEha",
	"precio_divisas_libra": "precio_divisa_precio_divisas_libra__xJnTn",
	"codigo": "precio_divisa_codigo__66qjr",
	"nombre": "precio_divisa_nombre__uE5As",
	"precio_dolar": "precio_divisa_precio_dolar__FO96e",
	"precio_libra": "precio_divisa_precio_libra__fDvDu",
	"boton_llamar_divisa": "precio_divisa_boton_llamar_divisa__MSah4",
	"contenedor_botones": "precio_divisa_contenedor_botones__MUCTq",
	"contenedor_modal": "precio_divisa_contenedor_modal__Fad9Y",
	"contenedor": "precio_divisa_contenedor__MCvAQ",
	"card_body": "precio_divisa_card_body__Y_vD0",
	"card_header": "precio_divisa_card_header__nxZCh",
	"menu_divisa": "precio_divisa_menu_divisa__FxscJ",
	"select_compra": "precio_divisa_select_compra__RiI3t",
	"select_venta": "precio_divisa_select_venta__fgh5i",
	"selecciona_cambio": "precio_divisa_selecciona_cambio__FnFAJ",
	"moneda_habitual": "precio_divisa_moneda_habitual__q2lGh",
	"moneda_habitual_selected": "precio_divisa_moneda_habitual_selected__DrbyN",
	"activo": "precio_divisa_activo__khjNZ",
	"precio_cambio": "precio_divisa_precio_cambio__gS6Cm",
	"comprar": "precio_divisa_comprar__sEvrP",
	"cambio_compra": "precio_divisa_cambio_compra__p_xqm",
	"cambio_venta": "precio_divisa_cambio_venta__AHoCS",
	"valor_cambioeur": "precio_divisa_valor_cambioeur__2VHOu",
	"lista_moneda": "precio_divisa_lista_moneda__gOsSZ",
	"operacion_cambio": "precio_divisa_operacion_cambio__I8IiV",
	"campoA": "precio_divisa_campoA__NVBxv",
	"campoB": "precio_divisa_campoB__bJVhe",
	"contenedor_cambio": "precio_divisa_contenedor_cambio__nAJKy",
	"inputA": "precio_divisa_inputA__Kl5Rp",
	"inputB": "precio_divisa_inputB__Gvbb8",
	"cambios_habituales": "precio_divisa_cambios_habituales__cxulD"
};


/***/ }),

/***/ 1519:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_precio_oro": "precio_oro_contenedor_precio_oro__q3H50",
	"bloque_der_oro": "precio_oro_bloque_der_oro__juMmJ",
	"titulo_destacado": "precio_oro_titulo_destacado__9CybG",
	"precio_normal": "precio_oro_precio_normal__f9bEI",
	"precio_destacado": "precio_oro_precio_destacado__IdXgh",
	"simbolos": "precio_oro_simbolos__SR6av",
	"texto_para_mas": "precio_oro_texto_para_mas__Sj_bc",
	"boton_llamar_oro": "precio_oro_boton_llamar_oro__CuLNK",
	"contenedor_botones": "precio_oro_contenedor_botones__OCK7z",
	"contenedor_modal": "precio_oro_contenedor_modal__HlyAm",
	"contenedorOro": "precio_oro_contenedorOro__kY0Mv",
	"titulo_servicio": "precio_oro_titulo_servicio__yCyHu",
	"ver_precio_plata": "precio_oro_ver_precio_plata__oug_3",
	"contenedor_calculadora": "precio_oro_contenedor_calculadora___QCmJ",
	"bloque_precios": "precio_oro_bloque_precios__2cgpV",
	"bloque_titulos": "precio_oro_bloque_titulos__KlXK8",
	"contenedor_precio_normal": "precio_oro_contenedor_precio_normal__BCa0Y",
	"precioNew18K": "precio_oro_precioNew18K__dfoGE",
	"texto_paramas_destacado": "precio_oro_texto_paramas_destacado__ifJwf",
	"texto_paramas": "precio_oro_texto_paramas__31uqG",
	"tabla_precios": "precio_oro_tabla_precios__LkySk",
	"precios_izq": "precio_oro_precios_izq__jsudS",
	"precios_der": "precio_oro_precios_der__DAUnH",
	"precio24": "precio_oro_precio24__ieYp3",
	"precio18": "precio_oro_precio18__fsURc",
	"precio14": "precio_oro_precio14__plluR",
	"simbolo_precio": "precio_oro_simbolo_precio__LMEsx",
	"precio_tabla_24k": "precio_oro_precio_tabla_24k__k6fks",
	"precio_tabla_18k": "precio_oro_precio_tabla_18k__ORHpC",
	"precio_tabla_14k": "precio_oro_precio_tabla_14k__Mm1_s",
	"simbolos_euro_gramos": "precio_oro_simbolos_euro_gramos__Zp0_1",
	"ver_precios_oro": "precio_oro_ver_precios_oro__tnmSJ",
	"calculadora_izq": "precio_oro_calculadora_izq__NFUXG",
	"icono_flecha": "precio_oro_icono_flecha__jF9BU",
	"peso_joyas": "precio_oro_peso_joyas__UCgpL",
	"calculadora_der": "precio_oro_calculadora_der__eKfTQ",
	"precio_total": "precio_oro_precio_total__0KjCK",
	"contenedorMasPrecioOro": "precio_oro_contenedorMasPrecioOro__NO8gv",
	"popup_oro_activo": "precio_oro_popup_oro_activo__ieBjT",
	"cerrar_oro_volver": "precio_oro_cerrar_oro_volver__YQlGT",
	"cerrar_oro": "precio_oro_cerrar_oro__BJL8T",
	"texto_paramas_popup": "precio_oro_texto_paramas_popup__L6YiG",
	"precio_metales": "precio_oro_precio_metales__Z5igF",
	"tablasMas24k": "precio_oro_tablasMas24k__3fS6L",
	"tablasMas18k": "precio_oro_tablasMas18k__rUYlh",
	"tablasMas14k": "precio_oro_tablasMas14k__tec1f",
	"kilates_tabla": "precio_oro_kilates_tabla__xlZv8",
	"precio_tabla24k": "precio_oro_precio_tabla24k__aHRX5",
	"precio_tabla14k": "precio_oro_precio_tabla14k__nwqar",
	"precio_tabla18k": "precio_oro_precio_tabla18k__dujks",
	"simbolos_popup": "precio_oro_simbolos_popup__9PmWc"
};


/***/ }),

/***/ 3423:
/***/ ((module) => {

// Exports
module.exports = {
	"resenas": "resenas_resenas__ekR4i"
};


/***/ }),

/***/ 6241:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Boton1)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _boton_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5356);
/* harmony import */ var _boton_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_boton_module_css__WEBPACK_IMPORTED_MODULE_1__);


function Boton1({ contenido , openModal1  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_boton_module_css__WEBPACK_IMPORTED_MODULE_1___default().mas_precios_oro),
        onClick: openModal1,
        children: contenido
    });
}


/***/ }),

/***/ 1967:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Boton2)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _boton_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5356);
/* harmony import */ var _boton_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_boton_module_css__WEBPACK_IMPORTED_MODULE_1__);


function Boton2({ contenido , openModal2  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_boton_module_css__WEBPACK_IMPORTED_MODULE_1___default().calculadora_oro),
        onClick: openModal2,
        children: contenido
    });
}


/***/ }),

/***/ 1905:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Boton3)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _boton_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5356);
/* harmony import */ var _boton_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_boton_module_css__WEBPACK_IMPORTED_MODULE_1__);


function Boton3({ contenido , openModal3  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_boton_module_css__WEBPACK_IMPORTED_MODULE_1___default().info_oro),
        onClick: openModal3,
        id: "data_click",
        children: contenido
    });
}


/***/ }),

/***/ 169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Contenedor)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contenedor_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4689);
/* harmony import */ var _contenedor_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_contenedor_module_css__WEBPACK_IMPORTED_MODULE_1__);


function Contenedor({ children  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_contenedor_module_css__WEBPACK_IMPORTED_MODULE_1___default().contenedor),
            children: children
        })
    });
}


/***/ }),

/***/ 3471:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Empenos)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./componentes/empeños/empenos.module.css
var empenos_module = __webpack_require__(1146);
var empenos_module_default = /*#__PURE__*/__webpack_require__.n(empenos_module);
// EXTERNAL MODULE: ./componentes/modal/useModal.js
var useModal = __webpack_require__(5440);
// EXTERNAL MODULE: ./componentes/modal/Modal.js
var Modal = __webpack_require__(9562);
// EXTERNAL MODULE: ./componentes/botones/Boton1.js
var Boton1 = __webpack_require__(6241);
// EXTERNAL MODULE: ./componentes/botones/Boton2.js
var Boton2 = __webpack_require__(1967);
// EXTERNAL MODULE: ./componentes/botones/Boton3.js
var Boton3 = __webpack_require__(1905);
// EXTERNAL MODULE: ./componentes/empenoEjemplo/empenoEjemplo.module.css
var empenoEjemplo_module = __webpack_require__(9104);
var empenoEjemplo_module_default = /*#__PURE__*/__webpack_require__.n(empenoEjemplo_module);
;// CONCATENATED MODULE: ./componentes/empenoEjemplo/EmpenoEjemplo.js


function EmpenosEjemplo() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (empenoEjemplo_module_default()).ejemplo_new,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: "Pongamos un ejemplo"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            "Para un empe\xf1o con inter\xe9s al ",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: "8% mensual"
                            }),
                            " y",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: " 0% de inter\xe9s"
                            }),
                            " primer mes (",
                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                children: "va asociada a un peque\xf1o gasto de gesti\xf3n del 3%"
                            }),
                            "):"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            "Si tu empe\xf1o tiene un ",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {}),
                            "valor de 100€,",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: " recibes 97€"
                            }),
                            "."
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            "Para recuperar tus piezas ",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: "pasado el primer mes"
                            }),
                            " y finalizar el contrato deber\xe1s abonar ",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: "100€"
                            }),
                            "."
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (empenoEjemplo_module_default()).boton_llamar_empenos,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    href: "tel:912 29 68 55",
                    title: "Tel\xe9fono de Quickgold Alcobendas",
                    children: [
                        "LLAMA YA PULSANDO AQUI",
                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                            className: (empenoEjemplo_module_default()).telefono_oro,
                            children: " 912 29 68 55"
                        })
                    ]
                })
            })
        ]
    });
}

// EXTERNAL MODULE: ./componentes/empenoInfo/empenoInfo.module.css
var empenoInfo_module = __webpack_require__(9792);
var empenoInfo_module_default = /*#__PURE__*/__webpack_require__.n(empenoInfo_module);
;// CONCATENATED MODULE: ./componentes/empenoInfo/EmpenoInfo.js


function EmpenosInfo() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (empenoInfo_module_default()).bloqueTitulo,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                    className: (empenoInfo_module_default()).titulo_servicio,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                            children: "Empe\xf1o"
                        }),
                        " de joyas"
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (empenoInfo_module_default()).empeno_der,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (empenoInfo_module_default()).caracteristica,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (empenoInfo_module_default()).caracteristica_empeno,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (empenoInfo_module_default()).porcentaje,
                                        children: "8%"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: (empenoInfo_module_default()).texto,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                children: "Inter\xe9s"
                                            }),
                                            " Mensual"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (empenoInfo_module_default()).caracteristica_empeno,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (empenoInfo_module_default()).porcentaje,
                                        children: "100%"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (empenoInfo_module_default()).texto,
                                        children: "Tasaci\xf3n"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (empenoInfo_module_default()).caracteristica_empeno,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (empenoInfo_module_default()).porcentaje,
                                        children: "0%"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (empenoInfo_module_default()).texto,
                                        children: "Primer mes"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (empenoInfo_module_default()).info_empenos,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            children: [
                                "En",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: " Quickgold"
                                }),
                                " llevamos",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: " m\xe1s de 10 a\xf1os de experiencia "
                                }),
                                "ofreciendo el servicio de pr\xe9stamos sobre joyas. Nuestra experiencia permite que nuestro servicio sea muy f\xe1cil para ti y r\xe1pido de realizar. Nuestro servicio est\xe1",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: " enfocado a que recuperes tus joyas"
                                }),
                                ", por esta raz\xf3n, nuestra promoci\xf3n permanante del primer mes sin inter\xe9s,",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "permite que recuperes tus joyas sin pagar ning\xfan inter\xe9s"
                                }),
                                "."
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (empenoInfo_module_default()).boton_llamar_empenos,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    href: "tel:912 29 68 55",
                    title: "Tel\xe9fono de Quickgold Alcobendas",
                    children: [
                        "LLAMA YA PULSANDO AQUI",
                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                            className: (empenoInfo_module_default()).telefono_oro,
                            children: " 912 29 68 55"
                        })
                    ]
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./componentes/empeños/Empenos.js









function Empenos() {
    const [isOpen1, openModal1, closeModal1] = (0,useModal/* useModal */.d)(false);
    const [isOpen2, openModal2, closeModal2] = (0,useModal/* useModal */.d)(false);
    const [isOpen3, openModal3, closeModal3] = (0,useModal/* useModal */.d)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: (empenos_module_default()).empenos,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (empenos_module_default()).contenedor_empenos,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (empenos_module_default()).contenedor_img_empenos,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "../../empenos.png",
                                    alt: "Empe\xf1os"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (empenos_module_default()).boton_llamar_empenos,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    href: "tel:912 29 68 55",
                                    title: "Tel\xe9fono de Quickgold Alcobendas",
                                    children: [
                                        "LLAMA YA PULSANDO AQUI",
                                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                            className: (empenos_module_default()).telefono_oro,
                                            children: " 912 29 68 55"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (empenos_module_default()).contenedor_botones,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Boton1/* default */.Z, {
                                openModal1: openModal1,
                                contenido: "EJEMPLO"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Boton2/* default */.Z, {
                                openModal2: openModal2,
                                contenido: "SIMULADOR"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Boton3/* default */.Z, {
                                openModal3: openModal3,
                                contenido: "INFO"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal/* default */.Z, {
                isOpen: isOpen1,
                closeModal: closeModal1,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (empenos_module_default()).contenedor_modal,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(EmpenosEjemplo, {})
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal/* default */.Z, {
                isOpen: isOpen2,
                closeModal: closeModal2,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (empenos_module_default()).contenedor_modal,
                    children: "modal simulador abierto"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal/* default */.Z, {
                isOpen: isOpen3,
                closeModal: closeModal3,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (empenos_module_default()).contenedor_modal,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(EmpenosInfo, {})
                })
            })
        ]
    });
}


/***/ }),

/***/ 5367:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Info_tiendas)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./componentes/modal/Modal.js
var Modal = __webpack_require__(9562);
// EXTERNAL MODULE: ./componentes/modal/useModal.js
var useModal = __webpack_require__(5440);
// EXTERNAL MODULE: ./componentes/mapa_tienda/mapa_tienda.module.css
var mapa_tienda_module = __webpack_require__(1199);
var mapa_tienda_module_default = /*#__PURE__*/__webpack_require__.n(mapa_tienda_module);
;// CONCATENATED MODULE: ./componentes/mapa_tienda/Mapa_tienda.js


function Mapa_tienda({ dataIdWp  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (mapa_tienda_module_default()).mapa_tienda_popup,
            children: /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                loading: "lazy",
                src: dataIdWp.acf.url_mapa_popup
            })
        })
    });
}

// EXTERNAL MODULE: ./componentes/info_tiendas/info_tiendas.module.css
var info_tiendas_module = __webpack_require__(4802);
var info_tiendas_module_default = /*#__PURE__*/__webpack_require__.n(info_tiendas_module);
;// CONCATENATED MODULE: ./componentes/info_tiendas/Info_tiendas.js





function Info_tiendas({ dataIdWp , placeid  }) {
    const [isOpen, openModal, closeModal] = (0,useModal/* useModal */.d)(false);
    const horarios = placeid?.result.opening_hours?.weekday_text;
    const listaHorarios = horarios.map((number, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
            className: `dia_${i++}`,
            children: number
        }, i));
    const resenas = placeid.result.rating;
    if (resenas > 4.7) {
        var img_valoracion = 69;
    } else if (resenas < 4.8 && resenas < 4.3) {
        var img_valoracion = 62;
    } else if (resenas < 4.4 && resenas < 3.7) {
        var img_valoracion = 55;
    } else if (resenas < 3.8 && resenas < 3.3) {
        var img_valoracion = 48;
    } else if (resenas < 3.4 && resenas < 2.7) {
        var img_valoracion = 41;
    } else if (resenas < 2.8 && resenas < 2.3) {
        var img_valoracion = 34;
    } else if (resenas < 2.4 && resenas < 1.7) {
        var img_valoracion = 27;
    } else if (resenas < 1.8 && resenas < 1.3) {
        var img_valoracion = 20;
    } else if (resenas < 1.4 && resenas < 0.7) {
        var img_valoracion = 13;
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: (info_tiendas_module_default()).contenedor_info_tienda,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (info_tiendas_module_default()).contenedor_info_mapa,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (info_tiendas_module_default()).contenedor_cabecera_tienda,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (info_tiendas_module_default()).cabecera_tienda,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (info_tiendas_module_default()).cabecera_titulo,
                                        children: placeid.result.name
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (info_tiendas_module_default()).cabecera_estrellas,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: (info_tiendas_module_default()).logo_google,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: "../../Recurso 1.png"
                                                })
                                            }),
                                            placeid.result.rating,
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: (info_tiendas_module_default()).img_stars,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    style: {
                                                        width: img_valoracion
                                                    },
                                                    className: (info_tiendas_module_default()).imgValoracion
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: (info_tiendas_module_default()).numero_reviews,
                                                children: [
                                                    placeid.result.user_ratings_total,
                                                    " rese\xf1as de Google"
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (info_tiendas_module_default()).boton_review,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: dataIdWp.acf.url_dejanos_opinion,
                                            target: "_blank",
                                            children: "D\xe9janos tu opini\xf3n"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (info_tiendas_module_default()).contenedor_tienda,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (info_tiendas_module_default()).contenido_tienda,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: (info_tiendas_module_default()).bloque_izq,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: (info_tiendas_module_default()).contenedor_izq,
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                            className: (info_tiendas_module_default()).direccion,
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                    children: "Direcci\xf3n: "
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    children: placeid.result.formatted_address
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                            className: (info_tiendas_module_default()).provincia,
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                    children: "Provincia: "
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    children: placeid.result.address_components[3].long_name
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                            className: (info_tiendas_module_default()).telefono_tienda,
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                    children: "Tel\xe9fono: "
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                    href: `tel:${placeid.result.formatted_phone_number}`,
                                                                    title: `Teléfono de Quickgold ${dataIdWp.acf.ciudad}`,
                                                                    children: placeid.result.formatted_phone_number
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: (info_tiendas_module_default()).contenedor_botones_tienda,
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    className: (info_tiendas_module_default()).llamar,
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                        href: `tel:${dataIdWp?.acf?.telefono}`,
                                                                        title: `Teléfono de Quickgold ${dataIdWp.acf.ciudad}`,
                                                                        children: "LLAMADA"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    className: (info_tiendas_module_default()).whatsapp_tienda,
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                        href: `https://wa.me/${dataIdWp?.acf?.telefono_mobil}`,
                                                                        title: `Whatsapp de Quickgold ${dataIdWp.acf.ciudad}`,
                                                                        target: "_blank",
                                                                        children: "WHATSAPP"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    onClick: openModal,
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        title: `Localización de Quickgold ${dataIdWp.acf.ciudad}`,
                                                                        className: (info_tiendas_module_default()).mapa_tienda,
                                                                        children: "MAPA"
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (info_tiendas_module_default()).bloque_der,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: (info_tiendas_module_default()).lista_horario,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                            children: "Horario Habitual: "
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                        className: (info_tiendas_module_default()).horario_tienda,
                                                        id: "lista-horario",
                                                        children: listaHorarios
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Modal/* default */.Z, {
                    isOpen: isOpen,
                    closeModal: closeModal,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Mapa_tienda, {
                        dataIdWp: dataIdWp
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 7625:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Invertir)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _invertir_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7718);
/* harmony import */ var _invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_invertir_module_css__WEBPACK_IMPORTED_MODULE_1__);


function Invertir() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().invertir),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().titulo),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    children: "Invertir en Oro"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().contenedor_tabla),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltip),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltiptext),
                                children: [
                                    "Oro fino 999,9",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "Medidas del blister:"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "14,95 x 7,95 x 0,437 mm"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Lingote 1g"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().precio),
                                children: "111€"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltip),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltiptext),
                                children: [
                                    "Oro fino 999,9",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "Medidas del blister:"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "14,95 x 7,95 x 0,437 mm"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Lingote 2.5g"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().precio),
                                children: "199€"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltip),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltiptext),
                                children: [
                                    "Oro fino 999,9",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "Medidas del blister:"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "14,95 x 7,95 x 0,437 mm"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Lingote 10g"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().precio),
                                children: "635€"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltip),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltiptext),
                                children: [
                                    "Oro fino 999,9",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "Medidas del blister:"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "14,95 x 7,95 x 0,437 mm"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Lingote 20g"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().precio),
                                children: "1,205€"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltip),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltiptext),
                                children: [
                                    "Oro fino 999,9",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "Medidas del blister:"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "14,95 x 7,95 x 0,437 mm"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Lingote 1Oz"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().precio),
                                children: "1,858€"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltip),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltiptext),
                                children: [
                                    "Oro fino 999,9",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "Medidas del blister:"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "14,95 x 7,95 x 0,437 mm"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Lingote 50g"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().precio),
                                children: "2,955€"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltip),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltiptext),
                                children: [
                                    "Oro fino 999,9",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "Medidas del blister:"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "14,95 x 7,95 x 0,437 mm"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Lingote 100g"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().precio),
                                children: "5,864€"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltip),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().tooltiptext),
                                children: [
                                    "Oro fino 999,9",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "Medidas del blister:"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "14,95 x 7,95 x 0,437 mm"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Lingote 250g"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_invertir_module_css__WEBPACK_IMPORTED_MODULE_1___default().precio),
                                children: "14,580€"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 9562:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Modal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _modal_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3673);
/* harmony import */ var _modal_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_modal_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_CancelRounded__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3802);
/* harmony import */ var _mui_icons_material_CancelRounded__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CancelRounded__WEBPACK_IMPORTED_MODULE_1__);



function Modal({ children , isOpen , closeModal  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `${(_modal_module_css__WEBPACK_IMPORTED_MODULE_2___default().contenedor_modal)} ${isOpen && (_modal_module_css__WEBPACK_IMPORTED_MODULE_2___default().is_open)}`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `${(_modal_module_css__WEBPACK_IMPORTED_MODULE_2___default().ventana_modal)} ${isOpen && (_modal_module_css__WEBPACK_IMPORTED_MODULE_2___default().is_open)}`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_modal_module_css__WEBPACK_IMPORTED_MODULE_2___default().boton_cerrar),
                    onClick: closeModal,
                    id: "data_click",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CancelRounded__WEBPACK_IMPORTED_MODULE_1___default()), {})
                }),
                children
            ]
        })
    });
}


/***/ }),

/***/ 5440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ useModal)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useModal = (initialValue = false)=>{
    const [isOpen, setIsOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialValue);
    const openModal = ()=>setIsOpen(true);
    const closeModal = ()=>setIsOpen(false);
    return [
        isOpen,
        openModal,
        closeModal
    ];
};


/***/ }),

/***/ 5554:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Precio_divisa)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./componentes/precio_divisa/precio_divisa.module.css
var precio_divisa_module = __webpack_require__(4565);
var precio_divisa_module_default = /*#__PURE__*/__webpack_require__.n(precio_divisa_module);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./componentes/modal/useModal.js
var useModal = __webpack_require__(5440);
// EXTERNAL MODULE: ./componentes/modal/Modal.js
var Modal = __webpack_require__(9562);
// EXTERNAL MODULE: ./componentes/botones/Boton1.js
var Boton1 = __webpack_require__(6241);
// EXTERNAL MODULE: ./componentes/botones/Boton2.js
var Boton2 = __webpack_require__(1967);
// EXTERNAL MODULE: ./componentes/botones/Boton3.js
var Boton3 = __webpack_require__(1905);
;// CONCATENATED MODULE: ./componentes/precio_divisa/Vender.js



const Vender = ({ dataDivisa  })=>{
    const dataCompras = dataDivisa.result.Tarifas.Divisas_Compra;
    const dataReverse = [
        ...dataCompras
    ].reverse();
    const [valorMoneda, setValorMoneda] = (0,external_react_.useState)(""); //este es el valor que viene de las opciones del select
    const [valorCodigo, setValorCodigo] = (0,external_react_.useState)(""); // este es el valor del data-codigo que viene del select
    const [tipoCambio, setTipoCambio] = (0,external_react_.useState)(false); // este es el valor que hace que se pinte el div azul donde aparecen las divisas al seleccionar el select una moneda
    const valorInput = valorMoneda / 1000; //aqui se formatea el valor que viene de la api por el select
    const valorCampo1 = 1 / valorInput;
    const refInput1 = (0,external_react_.useRef)();
    const refInput2 = (0,external_react_.useRef)();
    const refSelect = (0,external_react_.useRef)();
    const refHabitual = (0,external_react_.useRef)();
    const [addClase, setAddClase] = (0,external_react_.useState)(null);
    const captureSelect = (e)=>{
        setTipoCambio(true);
        setValorMoneda(e.target.value); //funcion que coge el valor del select
        setValorCodigo(e.target[e.target.selectedIndex].innerText);
    };
    const cambioValor = (monedaPais, i)=>{
        refSelect.current.value = monedaPais.Productos[0].Precio;
        setAddClase(i);
        captureSelect({
            target: {
                key: monedaPais.Productos[0].Id,
                label: monedaPais.Productos[0].Nombre,
                value: monedaPais.Productos[0].Precio,
                selectedIndex: i + 1,
                [i + 1]: {
                    innerText: monedaPais.Productos[0].Acronimo
                }
            }
        });
    };
    const filtro = dataReverse.filter((currency)=>{
        return currency.Name === "GBP" || currency.Name === "USD" || currency.Name === "CHF" || currency.Name === "BRL" || currency.Name === "CZK" || currency.Name === "CLP";
    });
    const calcularCambio = (event)=>{
        const { id , value: valor  } = event.target;
        let cambio = 0;
        if (id === "input-izquierdo") {
            // si cambia el input izquierdo, calcula el derecho
            cambio = valor * valorCampo1;
            refInput2.current.value = cambio.toFixed(4);
        } else {
            // si cambia el input derecho, calcula el izquierdo
            cambio = valor / valorCampo1;
            refInput1.current.value = cambio.toFixed(4);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (precio_divisa_module_default()).card_header,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                    children: [
                        "WE BUY Obt\xe9n ",
                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                            children: "euros"
                        }),
                        " por tus divisa extranjera"
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (precio_divisa_module_default()).card_body,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                        className: (precio_divisa_module_default()).conversorcompra,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (precio_divisa_module_default()).selecciona_cambio,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                                    ref: refSelect,
                                    className: (precio_divisa_module_default()).lista_moneda,
                                    value: valorMoneda,
                                    onChange: (e)=>{
                                        captureSelect(e);
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            id: "46",
                                            children: "SELECCIONAR DIVISA"
                                        }),
                                        dataReverse.map((post)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                id: post.Productos[0].Id,
                                                label: `${post.Productos[0]?.Acronimo} - ${post.Productos[0].Nombre}`,
                                                value: post.Productos[0].Precio,
                                                children: post.Productos[0].Acronimo
                                            }, post.Productos[0].Id))
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (precio_divisa_module_default()).contenedor_cambio,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: `${(precio_divisa_module_default()).precio_cambio} ${(precio_divisa_module_default()).comprar}`,
                                        children: [
                                            tipoCambio ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: (precio_divisa_module_default()).cambio_venta,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_divisa_module_default()).unidad,
                                                        children: "1"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: (precio_divisa_module_default()).codigo_moneda,
                                                        children: [
                                                            valorCodigo,
                                                            " "
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_divisa_module_default()).igual,
                                                        children: "="
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: (precio_divisa_module_default()).valor_cambioeur,
                                                        children: [
                                                            valorInput.toFixed(5),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                children: " €"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: (precio_divisa_module_default()).cambio_venta,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                        children: "Selecciona divisa"
                                                    }),
                                                    " para ver el tipo de cambio"
                                                ]
                                            }),
                                            tipoCambio ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: (precio_divisa_module_default()).cambio_compra,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_divisa_module_default()).unidad,
                                                        children: "1"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_divisa_module_default()).codigo_moneda,
                                                        children: "EUR"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_divisa_module_default()).igual,
                                                        children: "="
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: (precio_divisa_module_default()).valor_cambioeur,
                                                        children: [
                                                            valorCampo1.toFixed(5),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("strong", {
                                                                children: [
                                                                    " ",
                                                                    valorCodigo
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }) : ""
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (precio_divisa_module_default()).operacion_cambio,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: `${(precio_divisa_module_default()).grupo_monedas} ${(precio_divisa_module_default()).campoB}`,
                                                children: tipoCambio ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            children: valorCodigo
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            id: "input-derecho",
                                                            type: "text",
                                                            className: (precio_divisa_module_default()).inputA,
                                                            pattern: "[0-9]*",
                                                            placeholder: "Cantidad",
                                                            inputMode: "numeric",
                                                            ref: refInput2,
                                                            onChange: calcularCambio
                                                        })
                                                    ]
                                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            children: "___"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "text",
                                                            className: (precio_divisa_module_default()).inputA,
                                                            placeholder: "Cantidad",
                                                            disabled: true
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: `${(precio_divisa_module_default()).grupo_monedas} ${(precio_divisa_module_default()).campoA}`,
                                                children: tipoCambio ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            children: "EUR"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            ref: refInput1,
                                                            id: "input-izquierdo",
                                                            type: "text",
                                                            className: (precio_divisa_module_default()).inputA,
                                                            pattern: "[0-9]*",
                                                            placeholder: "cantidad",
                                                            inputMode: "numeric",
                                                            onChange: calcularCambio
                                                        })
                                                    ]
                                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            children: "___"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "text",
                                                            className: (precio_divisa_module_default()).inputA,
                                                            placeholder: "Cantidad",
                                                            disabled: true
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (precio_divisa_module_default()).cambios_habituales,
                        children: filtro.map((post, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                ref: refHabitual,
                                className: `${(precio_divisa_module_default()).moneda_habitual} ${addClase == i ? (precio_divisa_module_default()).moneda_habitual_selected : ""} `,
                                title: "Vender Libras Esterlinas",
                                "data-value": "",
                                onClick: ()=>cambioValor(post, i),
                                children: [
                                    post.Productos[0].Nombre,
                                    " a Euro"
                                ]
                            }, post.Productos[0].Id))
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const precio_divisa_Vender = (Vender);

;// CONCATENATED MODULE: ./componentes/precio_divisa/Comprar.js



const Comprar = ({ dataDivisa , data  })=>{
    const dataCompras = dataDivisa.result.Tarifas.Divisas_Venta;
    const dataReverse = [
        ...dataCompras
    ].reverse();
    const [valorMoneda, setValorMoneda] = (0,external_react_.useState)("0"); //este es el valor que viene de las opciones del select
    const [valorCodigo, setValorCodigo] = (0,external_react_.useState)(""); // este es el valor del data-codigo que viene del select
    const [tipoCambio, setTipoCambio] = (0,external_react_.useState)(false); // este es el valor que hace que se pinte el div azul donde aparecen las divisas al seleccionar el select una moneda
    const valorInput = valorMoneda / 1000; //aqui se formatea el valor que viene de la api por el select
    const valorCampo1 = 1 / valorInput;
    const refInput1 = (0,external_react_.useRef)();
    const refInput2 = (0,external_react_.useRef)();
    const refSelect = (0,external_react_.useRef)();
    const refHabitual = (0,external_react_.useRef)();
    const refOption = (0,external_react_.useRef)();
    const [addClase, setAddClase] = (0,external_react_.useState)(null);
    const [addClase2, setAddClase2] = (0,external_react_.useState)(null);
    const captureSelect = (e)=>{
        setTipoCambio(true);
        setValorMoneda(e.target.value); //funcion que coge el valor del select
        setValorCodigo(e.target[e.target.selectedIndex].innerText);
        setAddClase2(e.target[e.target.selectedIndex].id);
    //setValorCodigo(e.target[e.target.selectedIndex].innerText);
    };
    //console.log("posicion2", addClase2);
    //console.log("posicion", addClase);
    const cambioValor = (monedaPais, i)=>{
        refSelect.current.value = monedaPais.Productos[0].Precio;
        //const addClases = (refHabitual.current.id = monedaPais.Productos[0]?.Id);
        setAddClase(i);
        captureSelect({
            target: {
                key: monedaPais.Productos[0]?.Id,
                //label: monedaPais.Productos[0]?.Nombre,
                value: monedaPais.Productos[0]?.Precio,
                selectedIndex: i + 1,
                [i + 1]: {
                    innerText: monedaPais.Productos[0]?.Acronimo,
                    id: i
                }
            }
        });
    };
    const filtro = dataReverse.filter((currency)=>{
        return currency.Name === "GBP" || currency.Name === "CHF" || currency.Name === "BRL" || currency.Name === "CZK" || currency.Name === "CLP";
    });
    const calcularCambio = (event)=>{
        const { id , value: valor  } = event.target;
        let cambio = 0;
        if (id === "input-izquierdo") {
            // si cambia el input izquierdo, calcula el derecho
            cambio = valor * valorCampo1;
            refInput2.current.value = cambio.toFixed(4);
        } else {
            // si cambia el input derecho, calcula el izquierdo
            cambio = valor / valorCampo1;
            refInput1.current.value = cambio.toFixed(4);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (precio_divisa_module_default()).card_header,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                    children: [
                        "WE SELL Obt\xe9n ",
                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                            children: "divisa extranjera"
                        }),
                        " por tus euros."
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (precio_divisa_module_default()).card_body,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                        className: (precio_divisa_module_default()).conversorcompra,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (precio_divisa_module_default()).selecciona_cambio,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                                    ref: refSelect,
                                    className: (precio_divisa_module_default()).lista_moneda,
                                    onChange: (e)=>{
                                        captureSelect(e);
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            ref: refOption,
                                            id: "01",
                                            value: "0.0",
                                            children: "SELECCIONAR DIVISA"
                                        }),
                                        dataReverse.map((post, i)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                id: i,
                                                label: `${post.Productos[0]?.Acronimo} - ${post.Productos[0].Nombre}`,
                                                value: post.Productos[0]?.Precio,
                                                children: post.Productos[0]?.Acronimo
                                            }, post.Productos[0].Nombre))
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (precio_divisa_module_default()).contenedor_cambio,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: `${(precio_divisa_module_default()).precio_cambio} ${(precio_divisa_module_default()).comprar}`,
                                        children: [
                                            tipoCambio ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: (precio_divisa_module_default()).cambio_compra,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_divisa_module_default()).unidad,
                                                        children: "1"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_divisa_module_default()).codigo_moneda,
                                                        children: "EUR"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_divisa_module_default()).igual,
                                                        children: "="
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: (precio_divisa_module_default()).valor_cambioeur,
                                                        children: [
                                                            valorCampo1.toFixed(5),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                children: valorCodigo
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }) : "",
                                            tipoCambio ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: (precio_divisa_module_default()).cambio_venta,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_divisa_module_default()).unidad,
                                                        children: "1"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: (precio_divisa_module_default()).codigo_moneda,
                                                        children: [
                                                            valorCodigo,
                                                            " "
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_divisa_module_default()).igual,
                                                        children: "="
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: (precio_divisa_module_default()).valor_cambioeur,
                                                        children: [
                                                            valorInput.toFixed(5),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                children: "€"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: (precio_divisa_module_default()).cambio_venta,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                        children: "Selecciona divisa"
                                                    }),
                                                    " para ver el tipo de cambio"
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (precio_divisa_module_default()).operacion_cambio,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: `${(precio_divisa_module_default()).grupo_monedas} ${(precio_divisa_module_default()).campoA}`,
                                                children: tipoCambio ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            children: "EUR"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            id: "input-izquierdo",
                                                            ref: refInput1,
                                                            type: "text",
                                                            className: (precio_divisa_module_default()).inputA,
                                                            pattern: "[0-9]*",
                                                            placeholder: "Cantidad",
                                                            inputMode: "numeric",
                                                            onChange: calcularCambio
                                                        })
                                                    ]
                                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            children: "___"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "text",
                                                            className: (precio_divisa_module_default()).inputA,
                                                            placeholder: "Cantidad",
                                                            disabled: true
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: `${(precio_divisa_module_default()).grupo_monedas} ${(precio_divisa_module_default()).campoB}`,
                                                children: tipoCambio ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            children: valorCodigo
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            id: "input-derecho",
                                                            ref: refInput2,
                                                            type: "text",
                                                            className: (precio_divisa_module_default()).inputA,
                                                            pattern: "[0-9]*",
                                                            placeholder: "Cantidad",
                                                            inputMode: "numeric",
                                                            defaultValue: "",
                                                            onChange: calcularCambio
                                                        })
                                                    ]
                                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            children: "___"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "text",
                                                            className: (precio_divisa_module_default()).inputA,
                                                            placeholder: "Cantidad",
                                                            disabled: true
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (precio_divisa_module_default()).cambios_habituales,
                        children: filtro.map((post, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                ref: refHabitual,
                                id: post.Productos[0].Id,
                                className: `${(precio_divisa_module_default()).moneda_habitual} ${addClase && addClase2 == i ? (precio_divisa_module_default()).moneda_habitual_selected : ""} `,
                                title: `Vender ${post.Productos[0].Nombre}`,
                                onClick: ()=>cambioValor(post, i),
                                children: [
                                    "Euro a ",
                                    post.Productos[0].Nombre
                                ]
                            }, post.Productos[0].Id))
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const precio_divisa_Comprar = (Comprar);

;// CONCATENATED MODULE: ./componentes/precio_divisa/Precio_divisa.js










function Precio_divisa({ dataDivisa  }) {
    const [isOpen1, openModal1, closeModal1] = (0,useModal/* useModal */.d)(false);
    const [isOpen2, openModal2, closeModal2] = (0,useModal/* useModal */.d)(false);
    const [isOpen3, openModal3, closeModal3] = (0,useModal/* useModal */.d)(false);
    const [data, setData] = (0,external_react_.useState)(true);
    const data2 = ()=>setData(false);
    const data1 = ()=>setData(true);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: (precio_divisa_module_default()).contenedor_precio_divisa,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (precio_divisa_module_default()).bloque_divisa,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (precio_divisa_module_default()).menu_divisa,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: `${(precio_divisa_module_default()).select_compra} ${data && (precio_divisa_module_default()).activo}  `,
                                        onClick: ()=>{
                                            data1();
                                        },
                                        children: "QUIERO VENDER DIVISA"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: `${(precio_divisa_module_default()).select_venta} ${!data && (precio_divisa_module_default()).activo}  `,
                                        onClick: data2,
                                        children: "QUIERO COMPRAR DIVISA"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (precio_divisa_module_default()).precio_divisas,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (precio_divisa_module_default()).precio_divisas_dolar,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: (precio_divisa_module_default()).contenedor_der_divisa,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: "../../USD.png",
                                                    alt: "imagen dolar"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (precio_divisa_module_default()).contenedor_izq_divisa,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: (precio_divisa_module_default()).codigo,
                                                        children: "USD"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: (precio_divisa_module_default()).nombre,
                                                        children: "D\xf3lar USA"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: (precio_divisa_module_default()).precio_dolar,
                                                        children: [
                                                            "0.9164",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: (precio_divisa_module_default()).simbolo,
                                                                children: "€"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (precio_divisa_module_default()).precio_divisas_libra,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: (precio_divisa_module_default()).contenedor_der_divisa,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: "../../GBP.png",
                                                    alt: "imagen libra"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (precio_divisa_module_default()).contenedor_izq_divisa,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: (precio_divisa_module_default()).codigo,
                                                        children: "GBP"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: (precio_divisa_module_default()).nombre,
                                                        children: "Libra Esterlina"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: (precio_divisa_module_default()).precio_libra,
                                                        children: [
                                                            "1.1256",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: (precio_divisa_module_default()).simbolo,
                                                                children: "€"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (precio_divisa_module_default()).boton_llamar_divisa,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    href: "tel:912 29 68 55",
                                    title: "Tel\xe9fono de Quickgold Alcobendas",
                                    children: [
                                        "Llama al",
                                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                            className: (precio_divisa_module_default()).telefono_oro,
                                            children: " 912 29 68 55"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (precio_divisa_module_default()).contenedor_botones,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Boton1/* default */.Z, {
                                openModal1: openModal1,
                                contenido: "M\xc1S PRECIOS"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Boton2/* default */.Z, {
                                openModal2: openModal2,
                                contenido: "CONVERSOR"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Boton3/* default */.Z, {
                                openModal3: openModal3,
                                contenido: "INFO"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal/* default */.Z, {
                isOpen: isOpen1,
                closeModal: closeModal1,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (precio_divisa_module_default()).contenedor_modal,
                    children: "modal mas precios abierto"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal/* default */.Z, {
                isOpen: isOpen2,
                closeModal: closeModal2,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (precio_divisa_module_default()).contenedor_modal,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (precio_divisa_module_default()).contenedor,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (precio_divisa_module_default()).menu_divisa,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: `${(precio_divisa_module_default()).select_compra} ${data && (precio_divisa_module_default()).activo}  `,
                                        onClick: ()=>{
                                            data1();
                                        },
                                        children: "QUIERO VENDER DIVISA"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: `${(precio_divisa_module_default()).select_venta} ${!data && (precio_divisa_module_default()).activo}  `,
                                        onClick: data2,
                                        children: "QUIERO COMPRAR DIVISA"
                                    })
                                ]
                            }),
                            data ? /*#__PURE__*/ jsx_runtime_.jsx(precio_divisa_Vender, {
                                dataDivisa: dataDivisa
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(precio_divisa_Comprar, {
                                dataDivisa: dataDivisa,
                                data: data
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (precio_divisa_module_default()).boton_llamar_divisa,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    href: "tel:912 29 68 55",
                                    title: "Tel\xe9fono de Quickgold Alcobendas",
                                    children: [
                                        "Llama al",
                                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                            className: (precio_divisa_module_default()).telefono_oro,
                                            children: " 912 29 68 55"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal/* default */.Z, {
                isOpen: isOpen3,
                closeModal: closeModal3,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (precio_divisa_module_default()).contenedor_modal,
                    children: "modal info abierto"
                })
            })
        ]
    });
}


/***/ }),

/***/ 5134:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Precio_oro)
});

// UNUSED EXPORTS: getServerSideProps

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./componentes/precio_oro/precio_oro.module.css
var precio_oro_module = __webpack_require__(1519);
var precio_oro_module_default = /*#__PURE__*/__webpack_require__.n(precio_oro_module);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./componentes/modal/useModal.js
var useModal = __webpack_require__(5440);
// EXTERNAL MODULE: ./componentes/modal/Modal.js
var Modal = __webpack_require__(9562);
// EXTERNAL MODULE: ./componentes/botones/Boton1.js
var Boton1 = __webpack_require__(6241);
// EXTERNAL MODULE: ./componentes/botones/Boton2.js
var Boton2 = __webpack_require__(1967);
// EXTERNAL MODULE: ./componentes/botones/Boton3.js
var Boton3 = __webpack_require__(1905);
;// CONCATENATED MODULE: ./componentes/precio_oro/CalculadoraOro.js



const CalculadoraOro = ({ data  })=>{
    //const precio18 = DataCompra.find(p => p.Name === "18k");
    //const precio18k = precio18?.Productos[0]?.Precio / 1000;
    const datos = data.result.Tarifas.Oro;
    const [inputUsuario, setInputUsuario] = (0,external_react_.useState)("__.__");
    const precio18k = datos[2]?.Productos[0]?.Precio / 1000;
    const precio14k = datos[10]?.Productos[0]?.Precio / 1000;
    const precio24k = datos[12]?.Productos[0]?.Precio / 1000;
    (0,external_react_.useEffect)(()=>setInputUsuario("__.__"), []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (precio_oro_module_default()).contenedorOro,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (precio_oro_module_default()).bloque_titulo,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: (precio_oro_module_default()).titulo_servicio,
                        children: "Precio del oro"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (precio_oro_module_default()).contenedor_calculadora,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (precio_oro_module_default()).bloque_titulos,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    children: "PROMOCI\xd3N ONLINE"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    children: "TODOS NUESTROS PRECIOS DE COMPRA DE ORO"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (precio_oro_module_default()).bloque_precios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (precio_oro_module_default()).precios_izq,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (precio_oro_module_default()).precio_destacado,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: (precio_oro_module_default()).titulo_destacado,
                                                children: "Precio Oro 18K"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (precio_oro_module_default()).contenedor_precio_normal,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: (precio_oro_module_default()).precio_normal,
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: (precio_oro_module_default()).precioNew18K,
                                                                children: precio18k.toFixed(2)
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: (precio_oro_module_default()).simbolos,
                                                                children: "€/g"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: (precio_oro_module_default()).texto_paramas_destacado,
                                                        children: [
                                                            "M\xe1s de ",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: "100"
                                                            }),
                                                            "g"
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (precio_oro_module_default()).precios_der,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (precio_oro_module_default()).todos_precios,
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: (precio_oro_module_default()).texto_paramas,
                                                    children: [
                                                        "M\xe1s de ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: "100"
                                                        }),
                                                        "g"
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("table", {
                                                    className: (precio_oro_module_default()).tabla_precios,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                                    className: (precio_oro_module_default()).precio24,
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: (precio_oro_module_default()).simbolo_precio,
                                                                            children: "24K"
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                            className: (precio_oro_module_default()).precio_normal,
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: (precio_oro_module_default()).precio_tabla_24k,
                                                                                    children: precio24k.toFixed(2)
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: (precio_oro_module_default()).simbolos_euro_gramos,
                                                                                    children: "€/g"
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                                    className: (precio_oro_module_default()).precio18,
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: (precio_oro_module_default()).simbolo_precio,
                                                                            children: "18K"
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                            className: (precio_oro_module_default()).precio_normal,
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: (precio_oro_module_default()).precio_tabla_18k,
                                                                                    children: precio18k.toFixed(2)
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: (precio_oro_module_default()).simbolos_euro_gramos,
                                                                                    children: "€/g"
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                                    className: (precio_oro_module_default()).precio14,
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: (precio_oro_module_default()).simbolo_precio,
                                                                            children: "14K"
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                            className: (precio_oro_module_default()).precio_normal,
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: (precio_oro_module_default()).precio_tabla_14k,
                                                                                    children: precio14k.toFixed(2)
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: (precio_oro_module_default()).simbolos_euro_gramos,
                                                                                    children: "€/g"
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (precio_oro_module_default()).calculadora_precio,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (precio_oro_module_default()).calculadora_izq,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h5", {
                                                        children: [
                                                            "Tengo joyas de 18K que pesan un total de",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                type: "number",
                                                                className: (precio_oro_module_default()).peso_joyas,
                                                                size: "3",
                                                                autoComplete: "off",
                                                                min: "0",
                                                                onChange: (event)=>setInputUsuario(event.target.value)
                                                            }),
                                                            "g"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                                        children: [
                                                            "\xbfCu\xe1nto te vamos a dar por tus joyas?",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: `fa-solid fa-angles-right ${(precio_oro_module_default()).icono_flecha}`
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: (precio_oro_module_default()).calculadora_der,
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: (precio_oro_module_default()).precio_total,
                                                            children: [
                                                                inputUsuario < 100 ? inputUsuario * precio18k.toFixed(2) : inputUsuario * 35.46 || inputUsuario,
                                                                "€"
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const precio_oro_CalculadoraOro = (CalculadoraOro);

;// CONCATENATED MODULE: ./componentes/precio_oro/MasPreciosOro.js



const MasPreciosOro = ({ data  })=>{
    const datos = data.result.Tarifas.Oro;
    const precio18k = datos[2]?.Productos[0]?.Precio / 1000;
    const precio14k = datos[10]?.Productos[0]?.Precio / 1000;
    const precio24k = datos[12]?.Productos[0]?.Precio / 1000;
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (precio_oro_module_default()).contenedorMasPrecioOro,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (precio_oro_module_default()).contenedor_mas_precios,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (precio_oro_module_default()).bloque_titulos,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                children: "PROMOCI\xd3N ONLINE"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                children: "TODOS NUESTROS PRECIOS DE COMPRA DE ORO"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (precio_oro_module_default()).texto_paramas_popup,
                        children: [
                            "M\xe1s de",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (precio_oro_module_default()).paramas_oro_popup,
                                children: "100"
                            }),
                            "g"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("table", {
                        className: (precio_oro_module_default()).precio_metales,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                        className: (precio_oro_module_default()).tablasMas24k,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: (precio_oro_module_default()).kilates_tabla,
                                                children: "24K"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (precio_oro_module_default()).precio_normal,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: (precio_oro_module_default()).precio_tabla24k,
                                                        children: [
                                                            " ",
                                                            precio24k.toFixed(2)
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_oro_module_default()).simbolos_popup,
                                                        children: "€/g"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                        className: (precio_oro_module_default()).tablasMas18k,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: (precio_oro_module_default()).kilates_tabla,
                                                children: "24K"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (precio_oro_module_default()).precio_normal,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: (precio_oro_module_default()).precio_tabla18k,
                                                        children: [
                                                            " ",
                                                            precio18k.toFixed(2)
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_oro_module_default()).simbolos_popup,
                                                        children: "€/g"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                        className: (precio_oro_module_default()).tablasMas14k,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: (precio_oro_module_default()).kilates_tabla,
                                                children: "14K"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (precio_oro_module_default()).precio_normal,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: (precio_oro_module_default()).precio_tabla14k,
                                                        children: [
                                                            " ",
                                                            precio14k.toFixed(2)
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_oro_module_default()).simbolos_popup,
                                                        children: "€/g"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (precio_oro_module_default()).texto_paramas_popup,
                        children: [
                            "Menos de",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (precio_oro_module_default()).paramas_oro_popup,
                                children: "100"
                            }),
                            "g"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("table", {
                        className: (precio_oro_module_default()).precio_metales,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                        className: (precio_oro_module_default()).tablasMas24k,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: (precio_oro_module_default()).kilates_tabla,
                                                children: "24K"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (precio_oro_module_default()).precio_normal,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: (precio_oro_module_default()).precio_tabla24k,
                                                        children: [
                                                            " ",
                                                            precio24k.toFixed(2)
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_oro_module_default()).simbolos_popup,
                                                        children: "€/g"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                        className: (precio_oro_module_default()).tablasMas18k,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: (precio_oro_module_default()).kilates_tabla,
                                                children: "18K"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (precio_oro_module_default()).precio_normal,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: (precio_oro_module_default()).precio_tabla18k,
                                                        children: [
                                                            " ",
                                                            precio18k.toFixed(2)
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_oro_module_default()).simbolos_popup,
                                                        children: "€/g"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                        className: (precio_oro_module_default()).tablasMas14k,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: (precio_oro_module_default()).kilates_tabla,
                                                children: "14K"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (precio_oro_module_default()).precio_normal,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: (precio_oro_module_default()).precio_tabla14k,
                                                        children: [
                                                            " ",
                                                            precio14k.toFixed(2)
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: (precio_oro_module_default()).simbolos_popup,
                                                        children: "€/g"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (precio_oro_module_default()).boton_llamar_oro,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            href: "tel:912 29 68 55",
                            title: "Tel\xe9fono de Quickgold Alcobendas",
                            children: [
                                "Fija este precio llamando al",
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                    className: (precio_oro_module_default()).telefono_oro,
                                    children: " 912 29 68 55"
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const precio_oro_MasPreciosOro = (MasPreciosOro);

;// CONCATENATED MODULE: ./componentes/precio_oro/Precio_oro.js










function Precio_oro({ data  }) {
    const datos = data.result.Tarifas.Oro;
    const precio18k = datos[2]?.Productos[0]?.Precio / 1000;
    const [isOpen1, openModal1, closeModal1] = (0,useModal/* useModal */.d)(false);
    const [isOpen2, openModal2, closeModal2] = (0,useModal/* useModal */.d)(false);
    const [isOpen3, openModal3, closeModal3] = (0,useModal/* useModal */.d)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: (precio_oro_module_default()).contenedor_precio_oro,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (precio_oro_module_default()).bloque_der_oro,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (precio_oro_module_default()).contenedor_precio_destacado,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: (precio_oro_module_default()).titulo_destacado,
                                    children: "Precio Oro 18K"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (precio_oro_module_default()).precio_normal,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (precio_oro_module_default()).precio_destacado,
                                        children: precio18k.toFixed(2)
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (precio_oro_module_default()).simbolos,
                                        children: "€/g"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (precio_oro_module_default()).texto_para_mas,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        "M\xe1s de ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (precio_oro_module_default()).para_mas_oro,
                                            children: "100g"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (precio_oro_module_default()).boton_llamar_oro,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    href: "tel:912 29 68 55",
                                    title: "Tel\xe9fono de Quickgold Alcobendas",
                                    children: [
                                        "Fija este precio llamando al",
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                            className: (precio_oro_module_default()).telefono_oro,
                                            children: " 912 29 68 55"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (precio_oro_module_default()).contenedor_botones,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Boton1/* default */.Z, {
                                openModal1: openModal1,
                                contenido: "M\xc1S PRECIOS"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Boton2/* default */.Z, {
                                openModal2: openModal2,
                                contenido: "CALCULADORA"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Boton3/* default */.Z, {
                                openModal3: openModal3,
                                contenido: "INFO"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal/* default */.Z, {
                isOpen: isOpen1,
                closeModal: closeModal1,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (precio_oro_module_default()).contenedor_modal,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(precio_oro_MasPreciosOro, {
                        data: data
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal/* default */.Z, {
                isOpen: isOpen2,
                closeModal: closeModal2,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (precio_oro_module_default()).contenedor_modal,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(precio_oro_CalculadoraOro, {
                        data: data
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal/* default */.Z, {
                isOpen: isOpen3,
                closeModal: closeModal3,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (precio_oro_module_default()).contenedor_modal,
                    children: "modal info abierto"
                })
            })
        ]
    });
}
const ciudad = "barcelona";
async function getServerSideProps() {
    // Fetch data from external API
    const res = await fetch(`https://quickgold.es/archivos-cache/Fixing${ciudad}.txt`);
    const data1 = await res.json();
    console.log(data1);
    // Pass data to the page via props
    return {
        props: {
            data1
        }
    };
}


/***/ }),

/***/ 6603:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Resenas)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_joy_AspectRatio__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7069);
/* harmony import */ var _mui_joy_AspectRatio__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_joy_AspectRatio__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_joy_Box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4026);
/* harmony import */ var _mui_joy_Box__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_joy_Box__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_joy_Typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8104);
/* harmony import */ var _mui_joy_Typography__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_joy_Typography__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_joy_Card__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(755);
/* harmony import */ var _mui_joy_Card__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_joy_Card__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _resenas_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3423);
/* harmony import */ var _resenas_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_resenas_module_css__WEBPACK_IMPORTED_MODULE_5__);






const data = [
    {
        src: "https://images.unsplash.com/photo-1502657877623-f66bf489d236",
        title: "Night view",
        description: "4.21M views"
    },
    {
        src: "https://images.unsplash.com/photo-1527549993586-dff825b37782",
        title: "Lake view",
        description: "4.74M views"
    },
    {
        src: "https://images.unsplash.com/photo-1532614338840-ab30cf10ed36",
        title: "Mountain view",
        description: "3.98M views"
    }
];
function Resenas() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_resenas_module_css__WEBPACK_IMPORTED_MODULE_5___default().resenas),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    children: "Rese\xf1as de nuestros clientes"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_joy_Box__WEBPACK_IMPORTED_MODULE_2___default()), {
                    sx: {
                        display: "flex",
                        justifyContent: "center",
                        gap: 1,
                        py: 1,
                        overflow: "auto",
                        width: "100%",
                        scrollSnapType: "x mandatory",
                        "& > *": {
                            scrollSnapAlign: "center"
                        },
                        "::-webkit-scrollbar": {
                            display: "none"
                        }
                    },
                    children: data.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_joy_Card__WEBPACK_IMPORTED_MODULE_4___default()), {
                            row: true,
                            variant: "outlined",
                            sx: {
                                gap: 2,
                                border: 1,
                                "--Card-padding": (theme)=>theme.spacing(2)
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_joy_AspectRatio__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    ratio: "1",
                                    sx: {
                                        minWidth: 60,
                                        borderRadius: "sm",
                                        overflow: "auto"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: `${item.src}?h=120&fit=crop&auto=format`,
                                        srcSet: `${item.src}?h=120&fit=crop&auto=format&dpr=2 2x`,
                                        alt: item.title
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_joy_Box__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    sx: {
                                        whiteSpace: "nowrap",
                                        color: "#000"
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_joy_Typography__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            fontWeight: "md",
                                            children: item.title
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_joy_Typography__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            level: "body2",
                                            children: item.description
                                        })
                                    ]
                                })
                            ]
                        }, item.title))
                })
            })
        ]
    });
}


/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(3573)


/***/ })

};
;